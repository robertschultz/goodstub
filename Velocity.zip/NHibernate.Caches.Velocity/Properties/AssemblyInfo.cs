﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("NHibernate.Caches.Velocity")]
[assembly: AssemblyDescription("Cache provider for NHibernate using Velocity")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Heilig-Hartziekenhuis vzw")]
[assembly: AssemblyProduct("NHibernate.Caches.Velocity")]
[assembly: AssemblyCopyright("Copyright © Heilig-Hartziekenhuis vzw 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersionAttribute("3.1.0.4000")]
[assembly: AssemblyInformationalVersionAttribute("3.1.0.4000")]
[assembly: AssemblyFileVersionAttribute("3.1.0.4000")]
